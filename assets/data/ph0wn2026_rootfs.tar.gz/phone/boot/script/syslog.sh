#!/bin/sh
#***********************************************************************
# telapp.sh
#
# Shell script to Run Yealink sip telephone app
#
# Copyright 2001-2007 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#	Revision History:
#	Version		Author		Date				History
#
#***********************************************************************
strConfigFile=/config/system/system.ini
iSyslogdIP=`grep -i SyslogdIP $strConfigFile|cut -d "=" -f2`

echo "---------------------------------------"
echo "Starting the syslogd server"
echo "---------------------------------------"
#kill syslogd first anyway
killall -9 syslogd > /dev/null 2>&1

if [ -z $iSyslogdIP ];then
	echo "/sbin/syslogd -S -O /tmp/Messages -s 200 -b1"
	/sbin/syslogd -S -O /tmp/Messages -s 200 -b1
else
	echo "/sbin/syslogd -S -R $iSyslogdIP"
	/sbin/syslogd -S -R $iSyslogdIP
fi
