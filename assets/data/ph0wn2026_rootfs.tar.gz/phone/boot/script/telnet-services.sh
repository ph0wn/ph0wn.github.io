#!/bin/sh
echo "Estimating the telnet enable or not"

strConfigFile=/config/user/user.ini
killall -9 telnetd

itelnet_enable=`/boot/bin/cfgserver get features.temode`

echo $itelnet_enable
if [ "$itelnet_enable" -eq "1" ];then
	/usr/sbin/telnetd
	echo "telnet server enable!"
else
	echo "disable telnet server"
fi
