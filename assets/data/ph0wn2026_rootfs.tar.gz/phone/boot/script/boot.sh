#!/bin/sh

boot_set_phoneinfo()
{
	phoneoem=`/boot/bin/userenv -g phoneoem | cut -d "=" -f2`
	phonesid=`/boot/bin/userenv -g phonesid | cut -d "=" -f2`
	phonever=`/boot/bin/userenv -g phonever | cut -d "=" -f2`
	
	OEMNAME=`cat /phone/version | grep OEMNAME | cut -d "=" -f2`	
	ROMSID=`cat  /phone/version | grep ROMSID  | cut -d "=" -f2`
    ROMVER=`cat  /phone/version | grep FIRMWARE_VERSION | cut -d "=" -f2`
	
	if [ -z "$phoneoem" -o "$phoneoem" != "$OEMNAME" ];then
		if [ ! -z "$OEMNAME" ];then
			/boot/bin/userenv -s phoneoem -v $OEMNAME
		fi
	fi
	
	if [ -z "$phonesid" -o "$phonesid" != "$ROMSID" ];then
		if [ ! -z "$ROMSID" ];then
			/boot/bin/userenv -s phonesid -v $ROMSID
		fi
	fi
	
	if [ -z "$phonever" -o "$phonever" != "$ROMVER" ];then
		if [ ! -z "$ROMVER" ];then
			/boot/bin/userenv -s phonever -v $ROMVER
		fi
	fi

}

#
#path to export
#
PATH=$PATH:/boot/bin
PATH=$PATH:/phone/bin
export PATH

#
#check fs type
#
fstype=`cat /proc/mounts | grep /dev/root | cut -d ' ' -f3`
if [ $fstype == "yaffs2" ];then
	#mount phone
	phonemounted=`cat /proc/mounts | grep /dev/mtdblock10`
	if [ -z "$phonemounted" ];then
		mount -t yaffs2 -o ro /dev/mtdblock10 /phone
	fi
	#mount data
	mount -t yaffs2 -o rw /dev/mtdblock12 /data

	#mount config
	mount -t yaffs2 -o rw /dev/mtdblock11 /config
else
	#mount config
	mount -t jffs2 -o rw /dev/mtdblock11 /config
	chmod 770 /config
fi

#
# set some info to userenv
#
boot_set_phoneinfo

NeedSync=`/boot/bin/userenv -g NeedSync | cut -d "=" -f2`
if [ "$NeedSync" == "1" ];then
	#backup version.xml to config
	cp /boot/version.xml /config/version.xml
    rm -rf /config/etc
fi

#backup from reset factory 
if [ ! -f /config/version.xml ];then
	cp /boot/version.xml /config/version.xml
	sync
fi

#sync config
if [ -d /config/etc ]; then
	for i in `find /etc`
	do
		if [ -e $i -o -L $i ]; then
			if [ ! -e /config$i -a ! -L /config$i ];then
				echo "sync $i to /config$i"
				cp -a $i /config$i
			fi
		fi
	done
else
	echo "sync all /etc to /config/etc"
	cp -af /etc /config
fi
mount --bind /config/etc /etc 

#run normal mode script
/phone/scripts/phone.sh
