#!/bin/sh
#***********************************************************************
# PasswdCopy.sh
#
# Shell script to select web server type
#
# Copyright 2001-2008 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
# Revision History:
#***********************************************************************
echo "---------------------------------------"
echo "copy admin passwd from /config/.htpasswd to /tmp/.htpasswd"
echo "---------------------------------------"

HtpasswdFile=/config/.htpasswd

#copy admin user name and passwd from /config/.htpasswd to /tmp/.htpasswd
strAdmin=`grep admin $HtpasswdFile|cut -d " " -f2`
echo $strAdmin > /tmp/.htpasswd