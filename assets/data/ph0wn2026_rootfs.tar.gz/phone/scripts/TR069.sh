#!/bin/sh
if [ -x /phone/bin/tr069_client ]
then
echo "starting TR069 app..."
while [ "1" ]
do
    killall -9 tr069_client
    sleep 3
    /phone/bin/tr069_client > /dev/null 2>&1
done
echo "TR069 Terminated "
else
echo /phone/bin/tr069_client does not exist
fi