#!/bin/sh
#***********************************************************************
# TalkLogic.sh
#
# Shell script to Run Yealink TalkLogic app
#
# Copyright 2001-2007 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#   Revision History:
#   Version     Author      Date        History
#
#***********************************************************************

PHONETYPE=`/phone/scripts/GetPhoneType.sh`
PHONEVERSION=`/phone/scripts/GetPhoneType.sh version`
real_phone_type=`/phone/scripts/GetPhoneType.sh real_phone_type`

if [ "$PHONETYPE" != "T46" ] && [ "$PHONETYPE" != "T46S" ] \
   && [ "$PHONETYPE" != "T48S" ] && [ "$PHONETYPE" != "T48" ] \
   && [ "$PHONETYPE" != "T29" ] && [ "$PHONETYPE" != "T69" ] && [ "$PHONETYPE" != "DECT" ]; then
    PATH=$PATH:/phone/bin

    echo "---------------------------------------"
    echo "starting Screen app..."
    echo "---------------------------------------"
    while [ "1" ]
    do
        if [ -x /phone/bin/Screen.exe ]
        then
            /phone/bin/Screen.exe  > /dev/null
        else
            /phone/bin/Screen.exx > /dev/null
        fi
    done
    echo "---------------------------------------"
    echo "Screen Terminated "
    echo "---------------------------------------"
    exit 0
fi

echo Runing /phone/script/phoneapp.sh ...
#
cd /phone/bin/
if [ "$PHONEVERSION" == "81" ]
then
	if [ "$PHONETYPE" == "T48S" ] || [ "$PHONETYPE" == "T46S" ]
	then
		export QT_QWS_FONTDIR="/phone/resource/system/fonts/t4x/"
	else
		export QT_QWS_FONTDIR="/phone/resource/system/fonts/"
	fi
	
elif [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ]
then
    export QT_QWS_FONTDIR="/phone/resource/system/fonts/"
else
    export QT_QWS_FONTDIR="/phone/resource/fonts/"
fi


if [ "$PHONEVERSION" == "81" ] && [ "$PHONETYPE" == "T48S" ]
then
	export QT_PLUGIN_PATH="/phone/lib/plugins:/phone/lib/t48/plugins"
elif [ "$PHONEVERSION" == "81" ] && [ "$PHONETYPE" == "T46S" ]
then
	export QT_PLUGIN_PATH="/phone/lib/plugins:/phone/lib/t4x/plugins"
else
	export QT_PLUGIN_PATH="/phone/lib/plugins"
fi


if [ "$PHONETYPE" == "T29" ]; then
    export QWS_KEYBOARD="usb:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T29.qmap"

    rotateFile="/proc/lcd/rotate"
    bRotate=`cat $rotateFile`
    #if [ -f $rotateFile ] && [ "$bRotate" = "1" ]
    #then
        echo "rotate=1, screen rot 180!"
        export QWS_DISPLAY='Transformed:Rot180'
    #fi
fi

if [ "$PHONETYPE" == "T46" ] || [ "$PHONETYPE" == "T46S" ]; then
    if [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ] || [ "$PHONEVERSION" == "81" ]
    then
        if [ "$real_phone_type" == "T54S" ];then
            export QWS_KEYBOARD="usb:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T54.qmap"
        elif [ "$real_phone_type" == "T52S" ];then
            export QWS_KEYBOARD="usb:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T52.qmap"
        else
            export QWS_KEYBOARD="usb:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T46.qmap"
        fi
    else
        export QWS_KEYBOARD="usb:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T4X.qmap"
    fi
    
    if [ "$real_phone_type" != "T52S" ];then
        echo "rotate=1, screen rot 180!"
        export QWS_DISPLAY='Transformed:Rot180'
    else
        echo "rotate=1, screen rot 90!"
        export QWS_DISPLAY='Transformed:Rot90'
    fi
fi


if [ "$PHONETYPE" == "T46S" ]; then
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib/t4x
    export PATH=$PATH:/phone/bin/t4x
fi

if [ "$PHONETYPE" == "T48S" ]; then
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib/t48
    export PATH=$PATH:/phone/bin/t48
fi

if [ "$PHONETYPE" == "T69" ] || [ "$PHONETYPE" == "T69S" ]; then
    export QWS_KEYBOARD="usb:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T69.qmap"
    echo "rotate=1, screen rot 180!"
    export QWS_DISPLAY='Transformed:Rot180'
fi

if [ "$PHONETYPE" == "T48" ] || [ "$PHONETYPE" == "T48S" ]; then
    # enable QT Debug Info, Release version must be 0
    export QT_DEBUG_PLUGINS=1
    export QWS_MOUSE_PROTO="ylMouseDriverPlugin:/dev/input/TouchScreen"

    if [ $PHONEVERSION -le 40 ] || [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "81" ];then
        export QWS_KEYBOARD="ylKeyboardDriverPlugin:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T48.qmap"
    else
        export QWS_KEYBOARD="usb:/dev/keypad0:keymap=/phone/resource/device-res/keymap/T48.qmap"
    fi

    rotateFile="/proc/lcd/rotate"
    bRotate=`cat $rotateFile`
    if [ -f $rotateFile ] && [ "$bRotate" = "1" ]
    then
        echo "rotate=1, screen rot 180!"
        export QWS_DISPLAY='Transformed:Rot180'
    fi
	
	if [ "$PHONETYPE" == "T48" ]
	then
		export QWS_DISPLAY=bcmgfb
	fi
fi


echo "---------------------------------------"
echo "starting dskPhone app..."
echo "---------------------------------------"
while [ "1" ]
do

if [ "$PHONETYPE" == "T46S" ] && [ -x /phone/bin/t4x/dskPhone.exx ]; then
    trace=2 /phone/bin/t4x/dskPhone.exx -qws 2>&1
elif [ "$PHONETYPE" == "T48S" ] && [ -x /phone/bin/t48/dskPhone.exx ]; then
    trace=2 /phone/bin/t48/dskPhone.exx -qws 2>&1
else
    trace=2 /phone/bin/dskPhone.exx -qws 2>&1
fi
sleep 2
	
done
echo "---------------------------------------"
echo "dskPhone Terminated "
echo "---------------------------------------"
