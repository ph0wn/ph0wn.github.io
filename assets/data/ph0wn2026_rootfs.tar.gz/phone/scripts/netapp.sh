#!/bin/sh
#***********************************************************************
# TalkLogic.sh
#
# Shell script to Run Yealink TalkLogic app
#
# Copyright 2001-2007 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#   Revision History:
#   Version     Author      Date        History
#   1.0.0.1     kjf     2010-4-12 16:27 First Revision
#
#***********************************************************************

echo "---------------------------------------"
echo "starting rtServer app..."
echo "---------------------------------------"
while [ "1" ]
do
    /boot/bin/rtServer.exx 2>&1
    sleep 2
done
echo "---------------------------------------"
echo "rtServer Terminated "
echo "---------------------------------------"
