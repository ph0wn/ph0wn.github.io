#!/bin/sh
#
# Shell script to start testTool
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       1.0.0.1         QT            20110-06-22 20:36                First Revision
#
#***********************************************************************

echo /phone/scripts/ts_tool.sh  START

##show image fb
#only used in vpx
#idleBox.exx "setVideoDisplayOSDTransparency(0xff)"

##run calibrate
export TSLIB_CALIBFILE=/config/data/pointercal
/phone/bin/ts_calibrate.exx

factoryCalParam=`cat /config/data/pointercal`
/boot/bin/userenv -d /dev/mtd2 -s calparam -v "$factoryCalParam"

##set calibration param
if [ -e /config/data/pointercal ]; then
    ln -sf /config/data/pointercal /etc/pointercal
fi

echo /phone/scripts/ts_tool.sh  END