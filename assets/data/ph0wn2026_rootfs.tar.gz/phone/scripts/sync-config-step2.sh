#!/bin/sh
#
# Shell script to closeing upgrading : cover key files and recover configs
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       1.0.0.1         SYZ             2010-03-17 14:35                First Revision
#       1.0.0.2         KJF             2011-05-16 17:00                for V4X, new upgrade
#
#***********************************************************************

echo /phone/scripts/sync-config-step2.sh  Begin
###############################################################

NeedSync=`/boot/bin/userenv -g NeedSync | cut -d "=" -f2`

sync_immediate_config()
{
    if [ -x /boot/bin/cfgserver ];then
        iSyncIme=`/boot/bin/cfgserver getfac priv.sync.immediate.ime 0`
        iSyncTimezone=`/boot/bin/cfgserver getfac  priv.sync.immediate.timezone 0`
        iSyncPasswd=`/boot/bin/cfgserver getfac priv.sync.immediate.password 0`
        iSyncCusSoftkey=`/boot/bin/cfgserver getfac priv.sync.immediate.customsoftkey 0`
    else
        iSyncIme=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, ime, 0)"`
        iSyncTimezone=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, timezone, 0)"`
        iSyncPasswd=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, password, 0)"`
        iSyncCusSoftkey=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, customsoftkey, 0)"`
    fi

    echo "sync_immediate_config  ime:$iSyncIme  timezone:$iSyncTimezone  password:$iSyncPasswd  softkey:$iSyncCusSoftkey"

    if [ "$iSyncIme" -eq "1" ]
    then
        cp /phone/factory/ime/* /config/ime -arf
    fi

    if [ "$iSyncTimezone" -eq "1" ]
    then
        cp /phone/factory/data/AutoDST.xml /config/data -arf
    fi

    if [ "$iSyncPasswd" -eq "1" ]
    then
        cp /phone/factory/data/htpasswd /config/data -arf
    fi
	
    if [ "$iSyncCusSoftkey" -eq "1" ]
    then
        cp /phone/factory/softkey/* /config/softkey -arf
    fi
}

if [ -x /boot/bin/cfgserver ];then
    NeedCustomFac=`/boot/bin/userenv -g NeedCustomFac | cut -d "=" -f2`
    if [ "$NeedCustomFac" == "1" ];then
        echo sync custom factory
        /boot/bin/configTranslate.exx customfactory 1
        /boot/bin/userenv -s NeedCustomFac -v 0
    fi
fi

/phone/scripts/synccert.sh

## run from here
if [ "$NeedSync" == "0" ];then	
	#not need sync config
    echo No need to sync anything
    echo /phone/scripts/sync-config-step2.sh  END
	return
fi

if [ -x /boot/bin/cfgserver ];then
    if [ "$PHONETYPE" == "T46" ] || [ "$PHONETYPE" == "T41" ] \
       || [ "$PHONETYPE" == "T46S" ] || [ "$PHONETYPE" == "T27G" ]; then
        # adjust german language cfg
        strDeutsch=`ls -l /phone/resource/language/ | grep Deutsch`
        strGerman=`ls -l /phone/resource/language/ | grep German`
        strLang=`/boot/bin/cfgserver get lang.wui English`

        if [ "$strDeutsch" != "" -a "$strGerman" == "" -a "$strLang" == "German" ];then
            echo Found Deutsch and not found German!
            /boot/bin/cfgserver set lang.wui Deutsch
        fi

        if [ "$strDeutsch" == "" -a "$strGerman" != "" -a "$strLang" == "Deutsch" ];then
            echo Found German and not found Deutsch!
            /boot/bin/cfgserver set lang.wui German
        fi
    fi
fi

#sync ime timezone passwd
sync_immediate_config

#sync new config from factory while rom update
/phone/scripts/checkpassword.sh


## clean sync flag
/boot/bin/userenv -s NeedSync -v 0

echo /phone/scripts/sync-config-step2.sh  END

echo /phone/scripts/sync-config.sh  END

# nothing past this point #
