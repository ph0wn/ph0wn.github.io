#!/bin/sh
#***********************************************************************
# synccert.sh
#
# Shell script to Run Yealink cert sync
#
# Copyright 2001-2007 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date            History
#       1.0.0.1         yzh             2013-3-11       First Revision
#       1.0.0.1         hyy             2013-3-14       Modify sync logic
#
#***********************************************************************

#readme
#the step of cert sync is:
#1. do 'ln' all files from /phone/factory/certs/phoneca to /config/certs/phoneca
#2. do 'ln' all files from /config/certs and /phone/factory/certs/phoneca to /config/certs/ca
#3. no file in /config/certs/phonedev, 'ln' the pem file from /phone/factory/certs/

echo 'sync cert file begin'

rootPath='/config/certs'
factoryPath='/phone/factory/certs'
NeedSync=`/boot/bin/userenv -g NeedSync | cut -d "=" -f2`
if [ -x /boot/bin/cfgserver ];then
iSyncCertsAll=`/boot/bin/cfgserver getfac priv.sync.sync_certs 1`
else
iSyncCertsAll=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, icerts, 1)"`
fi
echo "sync cert all flag is $iSyncCertsAll"

lncert()
{
srcDir=$1"/"
dstDir=$2"/"

if [ ! -e $srcDir ] || [ ! -e $dstDir ]; then
    echo notexist $srcDir or $dstDir
    return
fi

echo ln cert file from $srcDir to $dstDir
for name in `ls $srcDir`
do
    #must not be dir
    #echo $srcDir$name
    if [ ! -f $srcDir$name ] || [ -e $dstDir$name ];then
        continue;
    fi

    #echo ln $srcDir$name $dstDir$name
    ln -s $srcDir$name $dstDir$name
done
}

if [ "$NeedSync" == "1" ] && [ "$iSyncCertsAll" == 1 ];then
cp $factoryPath /config/ -a
else
cp $factoryPath"/phoneca" $rootPath -a
cp $factoryPath"/generic" $rootPath -a
fi

if [ ! -e $rootPath"/ca" ]; then
    mkdir -p $rootPath"/ca"
fi

if [ ! -e $rootPath"/server" ]; then
    mkdir -p $rootPath"/server"
fi

if [ ! -e $rootPath"/phonedev" ]; then
    mkdir -p $rootPath"/phonedev"
fi

lncert $rootPath"/phoneca" $rootPath"/ca"
lncert $rootPath $rootPath"/ca"

#if there is no file in phonedev, 'ln' the pem file from generic to phonedev
if [ ! -f $rootPath"/phonedev/WebServer.pem" ] && [ -e $rootPath"/generic" ]; then
    lncert $rootPath"/generic" $rootPath"/phonedev"
fi

echo sync cert file end
