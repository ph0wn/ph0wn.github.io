#!/bin/sh
devBlockData=`mount | grep "/data " | awk '{print $1}'`

if [ "$devBlockData" == "" ];then
    if [ ! -e /config/upload ]; then
        mkdir -p /config/upload
    fi
    mount --bind /config/upload /data
fi
