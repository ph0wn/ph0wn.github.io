#!/bin/sh
#
#     $PHONETYPE               contain:
#      T23                      T23 T61 T66 T40
#      T41                      T41 T42 T27
#      T46                      T46
#      T48                      T48
#      T21                      T21 T19
#      T29                      T29
#      CP860                    CP860
#      T69                      T69G
#      DECT                     w52/w56

hw=`cat /proc/hwversion | awk -F. '{print $1}'`

if [ "$1" == "version" ];then
        VERSION=`grep FIRMWARE_VERSION /phone/version |cut -d '.' -f2`
        echo $VERSION
        exit
fi

if [ $hw == "44" ] || [ $hw == "47" ] || [ $hw == "48" ] || [ $hw == "52" ] || [ $hw == "53" ] || [ $hw == "54" ] || [ $hw == "76" ];then
        PHONETYPE=T23
fi

if [ $hw == "34" ] || [ $hw == "31" ];then
        PHONETYPE=T21
fi

if [ $hw == "36" ] || [ $hw == "29" ] || [ $hw == "45" ];then
        PHONETYPE=T41
fi

if [ $hw == "28" ];then
        PHONETYPE=T46
fi

if [ $hw == "35" ];then
        PHONETYPE=T48
fi

if [ $hw == "46" ];then
        PHONETYPE=T29
fi

if [ $hw == "37" ];then
        PHONETYPE=CP860
fi

if [ $hw == "57" ];then
        PHONETYPE=T69
fi

if [ $hw == "25" ];then
        PHONETYPE=DECT
fi

if [ $hw == "65" ];then
        PHONETYPE=T48S
fi

if [ $hw == "66" ] || [ $hw == "70" ] || [ $hw == "74" ];then
        PHONETYPE=T46S
fi

if [ $hw == "67" ];then
        PHONETYPE=T42S
fi

if [ $hw == "68" ];then
        PHONETYPE=T41S
fi

if [ $hw == "69" ];then
        PHONETYPE=T27G
fi

if [ "$1" == "real_phone_type" ];then
    if [ $PHONETYPE == "T46S" ];then
        if [ $hw == "70" ];then
            real_phone_type=T54S
        elif [ $hw == "74" ];then
            real_phone_type=T52S
        else
            real_phone_type=T46S
        fi
    else
        real_phone_type=$PHONETYPE
    fi
    echo $real_phone_type
    exit
fi

if [ "$1" == "screen_type" ];then
    if [ $PHONETYPE == "T23" ] || [ $PHONETYPE == "DECT" ] \
       || [ $PHONETYPE == "CP860" ] || [ $PHONETYPE == "T21" ] \
       || [ $PHONETYPE == "T41" ] || [ $PHONETYPE == "T69" ] \
       || [ $PHONETYPE == "T42S" ] || [ $PHONETYPE == "T41S" ] || [ $PHONETYPE == "T27G" ];then
        screen_type="WBlack"
    else
        screen_type="Color"
    fi
    echo $screen_type
    exit
fi

echo $PHONETYPE

