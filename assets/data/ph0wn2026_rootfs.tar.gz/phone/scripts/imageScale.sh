#!/bin/sh
#***********************************************************************
# imageScale.sh
#
# Shell script to Run Yealink TalkLogic app
#
# Copyright 2001-2007 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#   Revision History:
#   Version     Author      Date        History
#
#***********************************************************************

PHONETYPE=`/phone/scripts/GetPhoneType.sh`
PHONEVERSION=`/phone/scripts/GetPhoneType.sh version`

if [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ]; then
    export QT_QWS_FONTDIR=/phone/resource/system/fonts
	
elif [ "$PHONEVERSION" == "81" ]
then

	if [ "$PHONETYPE" == "T46S" ] || [ "$PHONETYPE" == "T48S" ]
	then
		export QT_QWS_FONTDIR=/phone/resource/system/fonts/t4x
	else
		export QT_QWS_FONTDIR=/phone/resource/system/fonts
	fi

else
    export QT_QWS_FONTDIR=/phone/resource/fonts
fi

if [ "$PHONEVERSION" == "81" ] && [ "$PHONETYPE" == "T48S" ]
then
	export QT_PLUGIN_PATH=/phone/lib:/phone/lib/t48:/phone/lib/plugins:/phone/lib/t48/plugins
elif [ "$PHONEVERSION" == "81" ] && [ "$PHONETYPE" == "T46S" ]
then 
	export QT_PLUGIN_PATH=/phone/lib:/phone/lib/t4x:/phone/lib/plugins:/phone/lib/t4x/plugins
else
	export QT_PLUGIN_PATH=/phone/lib:/phone/lib/plugins
fi

if [ "$PHONEVERSION" == "81" ] && [ "$PHONETYPE" == "T48S" ]
then
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib:/boot/lib:/phone/lib/t48:/phone/lib/plugins/imageformats:/phone/lib/t48/plugins/imageformats
elif [ "$PHONEVERSION" == "81" ] && [ "$PHONETYPE" == "T46S" ]
then 
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib:/boot/lib:/phone/lib/t4x::/phone/lib/plugins/imageformats/phone/lib/t4x/plugins/imageformats
else
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib:/boot/lib:/phone/lib/plugins/imageformats
fi

#plus $6
/phone/bin/imageScale.exx "$1" "$2" "$3" "$4" "$5" "$6"> /tmp/imageScale.out
