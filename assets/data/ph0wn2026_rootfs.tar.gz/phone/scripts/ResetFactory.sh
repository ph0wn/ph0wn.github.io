#!/bin/sh
#
# Be used only on T21/T19

if [ -f "/config/Factory/system/system.ini" ];then
    /phone/bin/Sync.exe 2
else
    /phone/bin/Sync.exe 1
fi

sync;sleep 1
sync;sleep 1

echo 201 > /proc/keypad/watchdog
echo 201 > /proc/keypad/watchdog
echo 201 > /proc/keypad/watchdog
