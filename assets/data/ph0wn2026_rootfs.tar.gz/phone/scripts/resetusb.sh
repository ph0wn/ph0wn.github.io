#!/bin/sh
#***********************************************************************
# resetusb.sh
# echo port down(0)/up(1) > /proc/usb_port/power
# Shell script to reset usb port
#
#***********************************************************************

real_phone_type=`/phone/scripts/GetPhoneType.sh real_phone_type`

if [ "$real_phone_type" == "T52S" ] || [ "$real_phone_type" == "T54S" ];then
    echo No need to reset usb
    return
fi

hwversion=`cat /proc/hwversion|cut -d '.' -f2`
if [ $hwversion -le 1 ] ; then
    echo "Power down usb port"
    echo 0 0 > /proc/usb_port/power
    echo 1 0 > /proc/usb_port/power
    sleep 30
    echo 0 1 > /proc/usb_port/power
    echo 1 1 > /proc/usb_port/power
    echo "Power up usb port"
fi
