#!/bin/sh
#
# Shell script to reset http/https servers call it after config changed
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#               0.71.201.1      YZH             2012-09-24 09:25                create T2x-v71 lighttpd script
#
#***********************************************************************
##���ø�Ŀ¼
if [ -e "/phone/html" ];then
	ROOT_DIR="/phone/html/"
fi

if [ -e "/yealink/html" ];then
	ROOT_DIR="/yealink/html/"
fi

if [ -e "/phone/www/" ];then
	ROOT_DIR="/phone/www/"
fi

if [ -f ${ROOT_DIR}WEB-INFO/scripts/tools.sh ]; then
    ${ROOT_DIR}WEB-INFO/scripts/tools.sh $1
fi

PHONETYPE=`/phone/scripts/GetPhoneType.sh`
PHONEVERSION=`/phone/scripts/GetPhoneType.sh version`
export LD_LIBRARY_PATH=/boot/lib:${ROOT_DIR}WEB-INFO/bin

strConfigFile=/config/system/system.ini
strLighttpdConfig=/phone/bin/lighttpd/config

killall -9 lighttpd
killall -9 fcgiServer.exx
rm /tmp/lighttpd-upload* -rf

if [ -x /boot/bin/cfgserver ];then
    bHttpEnable=`/boot/bin/cfgserver get wui.http_enable 1` 
    iHttpPort=`/boot/bin/cfgserver get network.port.http 80` 
    bHttpsEnable=`/boot/bin/cfgserver get wui.https_enable 1`
    iHttpsPort=`/boot/bin/cfgserver get network.port.https 443`
    bOnlyHttps=`/boot/bin/cfgserver getfac priv.web.onlyhttps 0`
else
	if [ $PHONETYPE == "T21" ] && [ "$PHONEVERSION" != "80" ] && [ "$PHONEVERSION" != "8" ] && [ "$PHONEVERSION" != "81" ];then
	    HtpasswdFile=/config/.htpasswd
	    #copy admin user name and passwd from /config/.htpasswd to /tmp/.htpasswd
	    if [ -e $HtpasswdFile ]
	    then
	        strAdmin=`grep admin $HtpasswdFile|cut -d " " -f2`
	        echo $strAdmin > /tmp/.htpasswd
	    else
	        echo "$HtpasswdFile not exit"
	    fi

	    #***********************************************************************
	    # get web server type
	    #***********************************************************************
	    strWebHttpEnable=`cat $strConfigFile | grep "\<bEnable_http\>" `

	    if [ -z "$strWebHttpEnable" ]
	    then
	        bHttpEnable=1
	        echo "default web server type:$bHttpEnable"
	    else
	        bHttpEnable=`grep "\<bEnable_http\>" $strConfigFile|cut -d "=" -f2`
	    fi

	    strWebHttpsEnable=`cat $strConfigFile | grep "\<bEnable_https\>" `

	    if [ -z "$strWebHttpsEnable" ]
	    then
	        bHttpsEnable=1
	        echo "default web server type:$bHttpsEnable"
	    else
	        bHttpsEnable=`grep "\<bEnable_https\>" $strConfigFile|cut -d "=" -f2`
	    fi

	    #***********************************************************************
	    # get http port
	    #***********************************************************************
	    strHttpPort=`cat $strConfigFile | grep "\<nPort_http\>" `

	    if [ -z "$strHttpPort" ]
	    then
	        iHttpPort=80
	        echo "default http port: $iHttpPort"
	    else
	        iHttpPort=`grep "\<nPort_http\>" $strConfigFile|cut -d "=" -f2`
	    fi

	    #***********************************************************************
	    # get https port
	    #***********************************************************************
	    strHttpsPort=`cat $strConfigFile | grep "\<nPort_https\>" `

	    if [ -z "$strHttpsPort" ]
	    then
	        iHttpsPort=443
	        echo "default https port: $iHttpsPort"
	    else
	        iHttpsPort=`grep "\<nPort_https\>" $strConfigFile|cut -d "=" -f2`
	    fi

	    #***********************************************************************
	    # get bOnlyHttps
	    #***********************************************************************
	    bOnlyHttps=`cat /phone/factory/system/system.ini | grep "\<bOnlyHttps\>" `

	    if [ -z "$bOnlyHttps" ];then
	        echo "bOnlyHttps: 0"
	    else
	        bOnlyHttps=`grep "\<bOnlyHttps\>" /phone/factory/system/system.ini|cut -d "=" -f2`
	        echo "bOnlyHttps: $bOnlyHttps"
	    fi


	else
	    #***********************************************************************
	    # get http enable
	    #***********************************************************************

	    bHttpEnable=`/boot/bin/idleBox.exx "regGetString($strConfigFile,HttpServer,bEnable,1)"`

	    #***********************************************************************
	    # get http port
	    #***********************************************************************

	    iHttpPort=`/boot/bin/idleBox.exx "regGetString($strConfigFile,HttpServer,nPort,80)"`

	    #***********************************************************************
	    # get https enable
	    #***********************************************************************

	    bHttpsEnable=`/boot/bin/idleBox.exx "regGetString($strConfigFile,HttpsServer,bEnable,1)"`

	    #***********************************************************************
	    # get https port
	    #***********************************************************************

	    iHttpsPort=`/boot/bin/idleBox.exx "regGetString($strConfigFile,HttpsServer,nPort,443)"`

	    bOnlyHttps=`/boot/bin/idleBox.exx "regGetString(/phone/factory/system/system.ini,HttpServer,bOnlyHttps,0)"`
	fi
fi	

if [ "$bOnlyHttps" -eq "1" ]; then
    bHttpEnable=1
    mkdir -p /tmp/web/lighttpd/config/
    cp -rf $strLighttpdConfig/* /tmp/web/lighttpd/config/ 2> /dev/null
    strLighttpdConfig=/tmp/web/lighttpd/config
    echo "fastcgi.default_https = 1" >> $strLighttpdConfig/conf.d/fastcgi.conf
fi

echo "http port:$iHttpPort"
echo "https port:$iHttpsPort"


if [ "$bHttpEnable" -eq "0" ]
then
    iHttpPort=0
    echo "http port close"
fi

if [ "$bHttpsEnable" -eq "0" ]
then
    iHttpsPort=0
    echo "https port close"
fi

echo "running http port:$iHttpPort"
echo "running https port:$iHttpsPort"


mkdir -p /tmp/log

bootmode=`/boot/bin/userenv -g BOOTMODE | cut -d "=" -f2`
if [ "$bootmode" == "safemode" ];then
    cd /boot/lighttpd/
    if [ -e /boot/lighttpd/config/lighttpd.conf ];then
        ./sbin/lighttpd -f /boot/lighttpd/config/lighttpd.conf -m ./lib/ -p $iHttpPort -s $iHttpsPort
        echo specal boot
    else
        ./sbin/lighttpd -f /phone/factory/lighttpd/lighttpd.conf -m ./lib/ -p $iHttpPort -s $iHttpsPort
    fi
else
    cd /phone/bin/lighttpd/

    if [ $PHONETYPE == "T21" ] && [ "$PHONEVERSION" != "80" ] && [ "$PHONEVERSION" != "8" ] && [ "$PHONEVERSION" != "81" ];then
        if [ -e /phone/bin/lighttpd/config/lighttpd.conf ];then
            ./sbin/lighttpd -f /phone/bin/lighttpd/config/lighttpd.conf -m ./lib/ -p $iHttpPort -s $iHttpsPort
        else
            ./sbin/lighttpd -f /phone/factory/lighttpd/lighttpd.conf -m ./lib/ -p $iHttpPort -s $iHttpsPort
        fi

        sleep 2
        killall -9 lighttpd
        killall -9 fcgiServer.exx
        sleep 2
    fi

    if [ -e $strLighttpdConfig/lighttpd.conf ];then
        ./sbin/lighttpd -f $strLighttpdConfig/lighttpd.conf -m ./lib/ -p $iHttpPort -s $iHttpsPort
        echo normal boot
    else
        ./sbin/lighttpd -f /phone/factory/lighttpd/lighttpd.conf -m ./lib/ -p $iHttpPort -s $iHttpsPort
    fi
fi
# nothing past this point #
