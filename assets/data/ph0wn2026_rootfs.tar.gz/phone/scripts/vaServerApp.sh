#!/bin/sh
#vaSeverApp.sh
PHONETYPE=`/phone/scripts/GetPhoneType.sh`

if [ $PHONETYPE != "T23" ] && [ $PHONETYPE != "T21" ];then
    echo "---------------------------------------"
    echo "insert vaServer modules..."
    echo "---------------------------------------"

    insmod /boot/driver/amxr.ko
    insmod /boot/driver/halaudio.ko
    insmod /boot/driver/halaudio_apm.ko
    insmod /boot/driver/pxcLdxSupport.ko
    insmod /boot/driver/pxcLdxHausware.ko
    insmod /boot/driver/ept_driver.ko
    
    if [ $PHONETYPE != "CP860" ];then
    	insmod /boot/driver/ept_core.ko
    	insmod /boot/driver/pcm_hook.ko
    fi

    echo "---------------------------------------"
    echo "exit insert vaServer modules..."
    echo "---------------------------------------"
fi


echo "---------------------------------------"
echo "starting vaSever..."
echo "---------------------------------------"

sleep 1

if [ -x /phone/bin/ipvpserver ]
then
    /phone/bin/ipvpserver 2>&1 &
else
    /phone/bin/vaServer 2>&1 &
fi

echo "---------------------------------------"
echo "exit VPM "
echo "---------------------------------------"
