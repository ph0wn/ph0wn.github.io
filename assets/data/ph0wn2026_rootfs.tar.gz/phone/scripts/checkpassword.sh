#!/bin/sh
#
# Shell script to closeing upgrading : cover key files and recover configs
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       1.0.0.1         Songk             2016 826 ：15:33:52           First Revision
#       
#
#***********************************************************************
if [ -x /boot/bin/cfgserver ];then
    iCheckPassword=`/boot/bin/cfgserver getfac priv.gui.factory.sync.password.check 0`
else
    iCheckPassword=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, checkpassword, 0)"`
fi

isAdminPwd=`/boot/bin/idleBox.exx "checkPassword(admin,admin)"` 

echo "check_password:$iCheckPassword isAdminPwd:$isAdminPwd"

if [ "$iCheckPassword" == "1" ] && [ "$isAdminPwd" == "true" ]; then
    if [ -x /boot/bin/cfgserver ];then
        Username=`/boot/bin/cfgserver getfac priv.gui.factory.sync.password.username admin`
        #Username="admin"
        Newpassword=`/boot/bin/cfgserver getfac priv.gui.factory.sync.password.oriented $Username`
    else
        Username=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, Username, admin)"`
        #Username="admin"
        Newpassword=`/boot/bin/idleBox.exx "regGetString(/phone/factory/user/user.ini, Sync, Newpassword, $Username)"`
    fi
	echo "Username:$Username Newpassword:$Newpassword"
	/boot/bin/idleBox.exx "updatePassword($Username, $Newpassword, /config/data/htpasswd)"
fi