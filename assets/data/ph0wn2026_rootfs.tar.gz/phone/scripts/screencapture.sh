#!/bin/sh
#***********************************************************************
# screencapture.sh
#
# Shell script to Run Yealink screenshot app
#
# Copyright 2001-2007 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#   Revision History:
#   Version     Author      Date        History
#   1.0.0.1     lusq     2016-8-31 09:a42 First Revision
#
#***********************************************************************
real_phone_type=`/phone/scripts/GetPhoneType.sh real_phone_type`

echo "---------------------------------------"
echo "starting screencapture app..."
echo "---------------------------------------"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib:/boot/lib

if [ "$real_phone_type" == "T46" ] || [ "$real_phone_type" == "T46S" ] || [ "$real_phone_type" == "T29" ]  || [ "$real_phone_type" == "T54S" ]
then
/phone/bin/screenshot.exx $1 color /dev/fb0 180

elif [ "$real_phone_type" == "T52S" ]
then
/phone/bin/screenshot.exx $1 color /dev/fb0 90

elif [ "$real_phone_type" == "T48" ] || [ "$real_phone_type" == "T48S" ]
then
/phone/bin/screenshot.exx $1 color /dev/fb0 0

elif [ "$real_phone_type" == "T49" ]
then
/phone/bin/screenshot.exx $1 color /dev/fb1 90

else
/phone/bin/screenshot.exx $1 black /dev/fb0 0

fi

echo "---------------------------------------"
echo "screencapture Terminated "
echo "---------------------------------------"
