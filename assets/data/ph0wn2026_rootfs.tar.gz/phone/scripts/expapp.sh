#!/bin/sh


echo Runing /phone/script/expapp.sh ...

if [ "$1" == "open" ];then
	pid=`ps| grep expcolor.exx | grep -v grep`
	if [ "$pid" == "" ];then
		echo expcolor.exx not exist
		export QT_QWS_FONTDIR="/phone/resource/system/fonts/t4x/"
		export QT_PLUGIN_PATH="/phone/lib/t4x/plugins:/phone/lib/plugins"
		export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib/t4x
		export PATH=$PATH:/phone/bin/t4x
		/phone/bin/expcolor.exx -qws &
	else
		echo expcolor.exx existed
	fi

elif [ "$1" == "close" ];then
	
	killall expcolor.exx
	echo expcolor.exx killed
	
else

echo /phone/scripts/expcolor.sh parameter invalid

fi

echo /phone/scripts/expcolor.sh  END




