#!/bin/sh
#
# Shell script to closeing upgrading : cover key files and recover configs
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       1.0.0.1         SYZ             2010-03-17 14:35                First Revision
#       1.0.0.2         KJF             2011-05-16 17:00                for V4X, new upgrade
#
#***********************************************************************

echo /phone/scripts/sync-config.sh  Begin

NeedSync=`/boot/bin/userenv -g NeedSync | cut -d "=" -f2`

sync_bt_config()
{
    if [ -e /config/bluetooth/bluetooth ] && [ -e /phone/factory/bluetooth/bluetooth ]; then
        cp -a /phone/factory/bluetooth/bluetooth/* /config/bluetooth/bluetooth
    fi
    
    if [ -e /config/bluetooth/dbus-1 ] && [ -e /phone/factory/bluetooth/dbus-1 ]; then
        cp -a /phone/factory/bluetooth/dbus-1/* /config/bluetooth/dbus-1
    fi
}

if [ -x /phone/bin/Sync.exe ];then
    /phone/bin/Sync.exe  > /dev/null  2>&1
    
    #sync new config from factory while rom update
    if [ "$NeedSync" == "1" ];then
        sync_bt_config
    fi
    echo /phone/scripts/sync-config.sh  END
    return
fi

## keep user old configs and update other new configs

recover_user_config()
{
    mkdir -p /tmp/config.recover
    cp -a /phone/factory/* /tmp/config.recover/ 2>/dev/null
    #remove data
    if [ -e /tmp/config.recover/data ];then
        rm -rf /tmp/config.recover/data
    fi
    #remove certs
    if [ -e /tmp/config.recover/certs ];then
        rm -rf /tmp/config.recover/certs
    fi
    #remove openvpn
    if [ -e /tmp/config.recover/openvpn ];then
        rm -rf /tmp/config.recover/openvpn
    fi
    #remove ime
    if [ -e /tmp/config.recover/ime ];then
        rm -rf /tmp/config.recover/ime
    fi
    
    #remove factory.dbx
    if [ -x /boot/bin/cfgserver ] && [ -e /tmp/config.recover/factory.dbx ]; then
            rm /tmp/config.recover/factory.dbx
    fi
    
	if [ -e /tmp/config.recover/softkey/ ];then
		rm -rf /tmp/config.recover/softkey/
	fi    

    if [ ! -x /boot/bin/cfgserver ];then
        /boot/bin/idleBox.exx 'configUpgrade(/config, /tmp/config.recover)'
        if [ "$PHONEVERSION" != "80" ] && [ "$PHONEVERSION" != "8" ]; then
            /boot/bin/idleBox.exx 'configCover(/tmp/config.recover, /config)'
        fi
    fi
}

save_recovered_files()
{
    if [ -e /tmp/config.recover ];then
        cp -a /tmp/config.recover/* /config/ 2>/dev/null
        rm -rf /tmp/config.recover
    fi
}

recover_config_etc()
{
    echo "umount /etc"
    umount /etc
    echo "reset /etc/[shadow|passwd|group|profile] to /config/etc"
    # delete first
    if [ -e /config/etc/shadow ] ; then
        rm /config/etc/shadow -rf
    fi
    if [ -e /config/etc/passwd ] ; then
        rm /config/etc/passwd -rf
    fi
    if [ -e /config/etc/group ] ; then
        rm /config/etc/group -rf
    fi
    if [ -e /config/etc/profile ] ; then
        rm /config/etc/profile -rf
    fi
    if [ -e /config/user/voip/sipAccount16.cfg ] ; then
        rm /config/user/voip/sipAccount16.cfg -rf
    fi

    # copy which need update
    if [ -e /etc/shadow ] ; then
        cp /etc/shadow /config/etc/ -af
    fi
    if [ -e /etc/passwd ] ; then
        cp /etc/passwd /config/etc/ -af
    fi
    if [ -e /etc/group ] ; then
        cp /etc/group /config/etc/ -af
    fi
    if [ -e /etc/profile ] ; then
        cp /etc/profile /config/etc/ -af
    fi

    mount --bind /config/etc /etc
}

recover_rfs_permission()
{
    echo "recover rfs permission"
    chmod 700 boot
    chmod 700 data
    chmod 700 phone
    chmod 700 phone/bin -R
    chmod 700 phone/www -R
    chmod 700 phone/html -R
    chmod 700 phone/lib -R
    chmod 700 phone/resource -R
    chmod 700 phone/scripts -R
    chmod 770 phone/factory -R

    chmod 770 config
    chmod 770 config/* -R
    chmod 700 config/etc
}
###############################################################

PHONETYPE=`/phone/scripts/GetPhoneType.sh`
PHONEVERSION=`/phone/scripts/GetPhoneType.sh version`

## delete vpPhone.ini
#cp860 v73�汾����ɾ�����ļ�
if [ "$PHONETYPE" != "CP860" ] || [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ] || [ "$PHONEVERSION" == "81" ];then
    if [ -e /config/user/vpPhone.ini ] ; then
        rm /config/user/vpPhone.ini
    fi
fi

## delete Dialing.xml,now just for T48
if [ "$PHONETYPE" == "T48" ] || [ "$PHONETYPE" == "T48S" ]; then
    if [ -e /config/softkey/Dialing.xml ] ; then
        rm /config/softkey/Dialing.xml
    fi
fi

## V80 menu index changed
if [ "$PHONEVERSION" != "80" ] && [ "$PHONETYPE" != "CP860" ] && [ "$PHONEVERSION" != "8" ] && [ "$PHONEVERSION" == "81" ]; then
    rm -rf /config/menu/
    cp -af /phone/factory/menu/ /config/
fi

## run from here
if [ "$NeedSync" == "0" ];then
    #not need sync config
    echo not need sync config
    #integrity scan
    if [ ! -x /boot/bin/cfgserver ];then
        echo integrity scan ...
        /boot/bin/idleBox.exx "configIntegrityScan(/phone/factory,/config,?)"
    fi
    
    # for touch screen current just T48, and T49 will come soon, to do ...
    if [ "$PHONETYPE" == "T48" ] || [ "$PHONETYPE" == "T48S" ];then
        if [ ! -e /config/data/pointercal ];then
            /phone/scripts/calibrate.sh
        fi
    fi
    /boot/bin/configTranslate.exx reboot
    
    #/phone/scripts/synccert.sh
    echo /phone/scripts/sync-config-step1.sh  End
    return
fi

## keep user old configs and update other new configs
if [ ! -x /boot/bin/cfgserver ];then
    if [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ] || [ "$PHONEVERSION" == "81" ]; then
        /boot/bin/configTranslate.exx backup
    else
        if [ -e /phone/bin/configTranslate.exx ];then
    	    /phone/bin/configTranslate.exx 1
        fi
    fi
fi

echo make base directory

mkdir -p /tmp/log /config/data /config/system
if [ "$PHONETYPE" != "CP860" ];then
    mkdir -p /data/userdata/sound
    mkdir -p /data/userdata/ePhoto
    mkdir -p /data/userdata/contact-image
    mkdir -p /data/userdata/AD
    mkdir -p /data/userdata/wallpaper
fi

if [ -e /config/system.ini ] ; then
    cp -a /config/system.ini /config/system/system.ini
fi

#if [ ! -x /boot/bin/cfgserver ];then
    if [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ] || [ "$PHONEVERSION" == "81" ]; then
        /boot/bin/configTranslate.exx all
    else
        if [ -e /phone/bin/configTranslate.exx ];then
    	    /phone/bin/configTranslate.exx all
        fi
    fi
#fi

if [ ! -x /boot/bin/cfgserver ];then
    /boot/bin/idleBox.exx "regReloadAllFile()"
fi

recover_user_config
save_recovered_files

# sync custom config
if [ -x /boot/bin/cfgserver ];then
    /boot/bin/userenv -s NeedCustomFac -v 1
else
    /boot/bin/configTranslate.exx customfactory 1
fi
#if [ ! -x /boot/bin/cfgserver ];then
#    /boot/bin/configTranslate.exx customfactory 1
#fi

#qtȷ����ʱ����T29��,���������������� to do..
if [ ! -x /boot/bin/cfgserver ];then
    if [ "$PHONETYPE" == "T46" ] || [ "$PHONETYPE" == "T41" ] \
       || [ "$PHONETYPE" == "T46S" ] || [ "$PHONETYPE" == "T27G" ]; then
        # adjust german language cfg
        strDeutsch=`ls -l /phone/resource/language/ | grep Deutsch`
        strGerman=`ls -l /phone/resource/language/ | grep German`
        strLang=`/boot/bin/idleBox.exx "regGetString(/config/user/user.ini, Language, ActiveWebLanguage, English)"`

        if [ "$strDeutsch" != "" -a "$strGerman" == "" -a "$strLang" == "German" ];then
            echo Found Deutsch and not found German!
            /boot/bin/idleBox.exx "regSetString(/config/user/user.ini, Language, ActiveWebLanguage, Deutsch)"
        fi

        if [ "$strDeutsch" == "" -a "$strGerman" != "" -a "$strLang" == "Deutsch" ];then
            echo Found German and not found Deutsch!
            /boot/bin/idleBox.exx "regSetString(/config/user/user.ini, Language, ActiveWebLanguage, German)"
        fi
    fi
fi

if [ ! -x /boot/bin/cfgserver ];then
    /boot/bin/idleBox.exx "regReloadAllFile()"
fi

srcDir=/phone/factory/data/
dstDir=/config/data/

for name in `ls $srcDir`
do
    echo $name
    [ ! -e $dstDir$name ] && cp -a $srcDir$name $dstDir
done

# recover cert file
echo recover cert file
if [ ! -e /config/certs ];then
    mkdir -p /config/certs
    cp -a /phone/factory/certs/* /config/certs/
fi

# recover ime file
echo recover ime file
if [ ! -e /config/ime ];then
    mkdir -p /config/ime
    cp -a /phone/factory/ime/* /config/ime/
fi

#if [ ! -e /etc/profile ] ; then
#   cp /phone/factory/profile /etc/profile -af
#fi

## V80 menu index changed
if [ "$PHONEVERSION" != "80" ] && [ "$PHONEVERSION" != "81" ] && [ "$PHONEVERSION" != "8" ] && [ "$PHONETYPE" != "CP860" ]; then
    echo recover menu data
    rm -rf /config/menu/
    cp -af /phone/factory/menu/ /config/
fi

#sync ime timezone passwd
#sync_immediate_config

## recover etc dir
recover_config_etc

## recover rfs permission
recover_rfs_permission

if [ -x /boot/bin/cfgserver ];then
    /boot/bin/cfgserver rootsync
fi

#sync new config from factory while rom update
if [ "$NeedSync" == "1" ];then
    sync_bt_config
fi

 #export mac-all to mac-upgrade
if [ ! -x /boot/bin/cfgserver ] && [ "$NeedSync" == "1" ] && [ $PHONEVERSION -ge "81" ];then
    echo "export all changed config to mac-upgrade.cfg"
    /boot/bin/configTranslate.exx exportallconfig /config/mac-upgrade.cfg
fi

##sync certs file
#/phone/scripts/synccert.sh

## clean sync flag--move to sync_immediate_config to end
#/boot/bin/userenv -s NeedSync -v 0

# for touch screen current just T48, and T49 will come soon, to do ...
## initialize calibrate
if [ "$PHONETYPE" == "T48" ] || [ "$PHONETYPE" == "T48S" ]; then
    if [ -e /phone/scripts/calibrate.sh ]; then
        /phone/scripts/calibrate.sh
    else
        echo /phone/scripts/calibrate.sh is not exist
    fi
fi


if [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ] || [ "$PHONEVERSION" == "81" ]; then
    /boot/bin/configTranslate.exx restore
else
    if [ -e /phone/bin/configTranslate.exx ]; then
        /phone/bin/configTranslate.exx 2
    fi
fi

echo /phone/scripts/sync-config-step1.sh  END

# nothing past this point #
