#!/bin/sh
echo 0 > /proc/sys/net/ipv6/conf/default/autoconf
echo 0 > /proc/sys/net/ipv6/conf/default/accept_ra
echo 1 >  /proc/sys/net/ipv6/conf/default/disable_ipv6
insmod /boot/driver/emac.ko
ifconfig eth0 up
echo 1 > /proc/emac/eth1_down
echo 0 > /proc/sys/net/ipv4/ip_forward