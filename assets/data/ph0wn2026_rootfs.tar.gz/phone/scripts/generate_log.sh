#!/bin/sh

outputFile=$1
echo "output to file $outputFile"

if [ "$outputFile" == "" ];then
    echo "need input outputfile name"
    exit 1
fi

sysConfigFile=/config/system/system.ini

#logName=`/boot/bin/idleBox.exx "netGetMACText(\0)"`
logName=`/sbin/ifconfig eth0 | sed -n '/HWaddr/ s/^.*HWaddr *//pg' | sed -r 's/^[[:space:]]*(.*[^[:space:]])([[:space:]]*)$/\1/g'| sed 's/://g'`
logName=$logName".log"

if [ -x /boot/bin/cfgserver ];then
    strLocalPath=`/boot/bin/cfgserver get syslog.local_path /tmp/log/`
    nFileKBytes=`/boot/bin/cfgserver get syslog.file_bytes 200`
else
    strLocalPath=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,Syslog,strLocalPath,/tmp/log/)"`
fi
strLocalPathFile="$strLocalPath""$logName"

i=20
while [ $i -ge 0 ]
do
    strLogI=$strLocalPathFile".$i"
    #echo "deal log $strLogI"
    if [ -f "$strLogI" ];then
        cat $strLogI >> $outputFile
    fi
    i=`expr $i - 1`
done
cat $strLocalPathFile >> $outputFile

for filelist in $(ls ${strLocalPath} | grep -v "$logName*")
do
    LogFile=$strLocalPath$filelist
    #echo $LogFile
    cat $LogFile >> $outputFile
done

cat /proc/uptime >> $outputFile
ifconfig >> $outputFile
ps >> $outputFile
top -b -n 1 -d 1 >> $outputFile
free >> $outputFile
cat /proc/meminfo >> $outputFile
cat /proc/buddyinfo >> $outputFile
df >> $outputFile
netstat -a >> $outputFile

pid=`ps |awk '{print $1}'`
for j in $pid
do
    cat /proc/$j/status >> $outputFile
done

echo "generate done"

