#!/bin/sh
#
# Shell script to reset QoS options call it after config changed
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       1.0.0.1         SYZ             2010-03-17 14:35                First Revision
#       1.0.0.2         KJF             2011-11-23 17:00                modify tos to dscp
#
#***********************************************************************

sipConfigFile=/config/user/voip/sipAccount0.cfg
sysConfigFile=/config/system/system.ini

if [ -x /boot/bin/cfgserver ];then
nSIPQoSValue=`/boot/bin/cfgserver get network.qos.signaltos 0`
nRTPQoSValue=`/boot/bin/cfgserver get network.qos.rtptos 0`

nMinRTPPort=`/boot/bin/cfgserver get network.port.min_rtpport 11780`
nMaxRTPPort=`/boot/bin/cfgserver get network.port.max_rtpport 11800`
nSIPPort=5060
else
nSIPQoSValue=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,QoS,nSipQoS,0)"`
nRTPQoSValue=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,QoS,nRTPQoS,0)"`

nMinRTPPort=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,RTPPORT,MinRTPPort,11780)"`
nMaxRTPPort=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,RTPPORT,MaxRTPPort,11800)"`
nSIPPort=`/boot/bin/idleBox.exx "regGetString($sipConfigFile,account,OutboundPort,5060)"`
fi

#/phone/bin/iptables -t mangle -L OUTPUT
/phone/bin/iptables -t mangle -F OUTPUT
/phone/bin/iptables -t mangle -A OUTPUT -p udp --destination-port $nSIPPort -j DSCP --set-dscp $nSIPQoSValue
/phone/bin/iptables -t mangle -A OUTPUT -p udp --source-port $nMinRTPPort:$nMaxRTPPort -j DSCP --set-dscp $nRTPQoSValue

# nothing past this point #
