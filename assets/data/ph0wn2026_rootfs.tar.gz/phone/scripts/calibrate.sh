#!/bin/sh
#
# Shell script to initialize calibrate
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
# Revision History:
# Version         Author          Date                            History
# 1.0.0.1         LIUQY           2013-08-29 10:50                First Revision
#
#***********************************************************************

echo /phone/scripts/Calibrate.sh  START

##get factoryCalParam

GetCalParam=`/boot/bin/userenv -d /dev/mtd2 -g calparam `
factoryCalParam=${GetCalParam#calparam=}

if [ -z "$factoryCalParam" ]; then
    echo factoryCalParam is not exit
else
    echo $factoryCalParam > /config/data/pointercal
fi

##set calibration param
if [ -e /config/data/pointercal ]; then
    ln -sf /config/data/pointercal /etc/pointercal
fi

echo /phone/scripts/Calibrate.sh  END