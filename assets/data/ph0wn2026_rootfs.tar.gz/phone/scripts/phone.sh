#!/bin/sh
#
# Shell script start phone setting and appplication follow rc.local
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       21.0.0.2         KJF            2012-06-10 17:00                First Revision
#
#***********************************************************************

echo /phone/scripts/phone.sh  Begin

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/phone/lib:/boot/lib
export PATH=$PATH:/phone/bin:/boot/bin
export HOME=/

PHONETYPE=`/phone/scripts/GetPhoneType.sh`
PHONEVERSION=`/phone/scripts/GetPhoneType.sh version`

if [ -f /config/simulator.sh ]; then
    /config/simulator.sh
else
    mkdir -p /tmp/log/

    ## init net driver
    # W52 same with T49/VC110,load driver by boot scripts
    if [ $PHONETYPE != "DECT" ];then
    /phone/scripts/NetDriver.sh
    fi
    	
    NeedSync=`/boot/bin/userenv -g NeedSync | cut -d "=" -f2`
    if [ ! -x /boot/bin/cfgserver ];then
	    if [ "$NeedSync" == "1" ];then
	        if [ -x /phone/bin/ConfigCheck.exx ];then
	            echo "phone checkconfig..."
	            /phone/bin/ConfigCheck.exx
	        elif [ -x /boot/bin/ConfigCheck.exx ];then
	            echo "boot checkconfig..."
	            /boot/bin/ConfigCheck.exx
	        elif [ -x /boot/bin/configTranslate.exx ] && [ $PHONEVERSION -ge "81" ];then
	             echo "Translate checkconfig..."
	            /boot/bin/configTranslate.exx exportforcesync
	        else
	            echo "ConfigCheck or configTranslate not exist"
	        fi
	    fi
    fi

    if [ -x /boot/bin/launcher ]
    then
        /boot/bin/launcher -d
    fi

    if [ "$PHONEVERSION" -lt "81" ];then
        /boot/bin/configServer.exx &
    fi
    #sync config
    /phone/scripts/sync-config-step1.sh

    if [ "$PHONEVERSION" -ge "81" ];then
        if [ -x /boot/bin/cfgserver ];then
            /boot/bin/cfgserver -d

        else
            /boot/bin/userenv -s configServer -v 0
            /boot/bin/configServer.exx &

            #waiting configServer init
            while : 
            do
                isInit=`/boot/bin/userenv -g configServer | cut -d "=" -f2`
                echo "isInit = $isInit"
                if [ "$isInit" == "1" ]; then
                    break
                else
                    usleep 500
                fi
            done
        fi
    fi
    /phone/scripts/sync-config-step2.sh
    
    #recover provider lock config
    if [ -f /config/providerLock.cfg ];then
        /boot/bin/autoServer.exx -f /config/providerLock.cfg
    fi
    
    ## reset syslog
    /phone/scripts/reset-syslog.sh

    if [ $PHONETYPE == "T46" ] || [ $PHONETYPE == "T48" ] || [ $PHONETYPE == "T29" ] || [ $PHONETYPE == "T69" ] \
       || [ "$PHONETYPE" == "T46S" ] || [ $PHONETYPE == "T48S" ];then
        ## reset usb port
        /phone/scripts/resetusb.sh &
        ## bluetooth
        /phone/scripts/btApp.sh
    fi

    if [ -f /phone/scripts/dns_cache.sh ]; then
        /phone/scripts/dns_cache.sh &
    fi

    #start led
    if [ $PHONETYPE == "DECT" ];then
    echo "starting Led..."
        if [ "$PHONEVERSION" -ge "81" ];then
            /phone/bin/Led.exx &
        else
            /phone/bin/dskPhone.exx -led -m stdout,time -l any=7& 
        fi
    fi
    		
    /phone/scripts/netapp.sh &

    if [ $PHONETYPE != "T46" ] && [ $PHONETYPE != "T48" ] && [ $PHONETYPE != "T29" ] && [ $PHONETYPE != "T69" ]\
        && [ "$PHONETYPE" != "T46S" ] && [ $PHONETYPE != "T48S" ];then
        /phone/scripts/mount.sh
        /phone/scripts/zero.sh
    fi

    #telnet-services
    /phone/scripts/TelnetServices.sh

    #start autoprovision server
    /boot/bin/autoServer.exx &

    if [ "$PHONETYPE" == "CP860" ] && [ "$PHONEVERSION" != "80" ] && [ "$PHONEVERSION" != "8" ] && [ "$PHONEVERSION" != "81" ];then
    	## reset qos setting
    	/phone/scripts/reset-qos.sh
    fi

    ## reset httpd/httpsd
    /phone/scripts/reset-httpd.sh

    /phone/scripts/vaServerApp.sh &

    /phone/scripts/phoneapp.sh &

    #sleep 10 seconds, wait rtServer config network finish
    if [ "$PHONEVERSION" != "80" ] && [ "$PHONEVERSION" != "8" ] && [ "$PHONEVERSION" != "81" ]; then
        sleep 10
    fi

    # run sipServer
    /phone/scripts/sipapp.sh &

    if [ -x /phone/bin/pcap.exx ]
    then
        /phone/bin/pcap.exx &
    fi

    # run tr069
    /phone/scripts/TR069.sh &

    if [ -x /phone/bin/uploadlogd ]
    then
        /phone/bin/uploadlogd &
    fi

    #needed by color screen.
    if [ $PHONETYPE == "T48" ] || [ $PHONETYPE == "T46" ] || [ $PHONETYPE == "T29" ] || [ $PHONETYPE == "T69" ] \
       || [ "$PHONETYPE" == "T46S" ] || [ $PHONETYPE == "T48S" ]; then
        mkdir -p /data/userdata/contact-image/icon/
    fi
    
    if [ "$PHONEVERSION" -ge "81" ];then
        screen_type=`/phone/scripts/GetPhoneType.sh screen_type`
        if [ $screen_type == "WBlack" ];then
            sleep 15
        else
            sleep 25
        fi

        /phone/scripts/generate_log.sh /tmp/boot.log
        rm -rf /tmp/log/*
    fi
fi

echo /phone/scripts/phone.sh  END
# nothing past this point #
