#!/bin/sh
#
# Shell script to reset syslogd call it after config changed
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       1.0.0.1         SYZ             2010-03-17 14:35                First Revision
#
#***********************************************************************
kill_process()
{
    for pid in $(ps | grep $1 | grep -v grep | awk '{print $1}');
    do
    kill -9 $pid
    done
    
    return 1
}

PHONETYPE=`/phone/scripts/GetPhoneType.sh`
PHONEVERSION=`/phone/scripts/GetPhoneType.sh version`

if [ "$PHONEVERSION" == 81 ];then
    SyslogdPath="/phone/bin/busybox syslogd"
else
    SyslogdPath="/sbin/syslogd"
fi

sysConfigFile=/config/system/system.ini

kill_process syslogd

if [ $PHONETYPE == "T21" ] && [ "$PHONEVERSION" != "80" ] && [ "$PHONEVERSION" != "8" ] && [ "$PHONEVERSION" != "81" ];then
    strLocalPath="/tmp/Messages"
    nFileKBytes="200"
else
    

    if [ -x /boot/bin/cfgserver ];then
        logName=`/sbin/ifconfig eth0 | sed -n '/HWaddr/ s/^.*HWaddr *//pg' | sed -r 's/^[[:space:]]*(.*[^[:space:]])([[:space:]]*)$/\1/g'| sed 's/://g'`
        echo $logName > /tmp/mac.tmp
        logName=$logName".log"
        strLocalPath=`/boot/bin/cfgserver get syslog.local_path /tmp/log/`
        nFileKBytes=`/boot/bin/cfgserver get syslog.file_bytes 200`
	strLocalPath="$strLocalPath""$logName"
    else
        `/boot/bin/idleBox.exx "netGetMACText(\0)" > /tmp/mac.tmp`
        logName=`/boot/bin/idleBox.exx "netGetMACText(\0)"`
        logName=$logName".log"
        strLocalPath=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,Syslog,strLocalPath,/tmp/log/)"`
	strLocalPath="$strLocalPath""$logName"
	nFileKBytes=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,Syslog,nFileKBytes,200)"`
    fi
fi

if [ "$PHONEVERSION" == 81 ];then
    if [ -x /boot/bin/cfgserver ];then
        nUplMaxKBytes=`/boot/bin/cfgserver get auto_provision.local_log.backup.append.max_file_size 512`
    else
        nUplMaxKBytes=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,Uplog,max_file_size,512)"`
    fi
    if [ $nFileKBytes -le $nUplMaxKBytes ];then
        nNotifyKBytes=$nFileKBytes
    else
        nNotifyKBytes=$nUplMaxKBytes
    fi    
    $SyslogdPath -S -O $strLocalPath -s $nFileKBytes -b5 -h $nNotifyKBytes -i /boot/bin/rtServer.exx
else
    $SyslogdPath -S -O $strLocalPath -s $nFileKBytes -b5
fi    

# nothing past this point #
