#!/bin/sh

if [ -x /boot/bin/cfgserver ];then
    DNSCacheEnable=`/boot/bin/cfgserver get network.dnscache.enable 0`
    DNSCacheMaxTTL=`/boot/bin/cfgserver get network.dnscache.maxttl 0`
else
    strConfigFile=/config/system/system.ini
    DNSCacheEnable=`/boot/bin/idleBox.exx "iniGetString($strConfigFile,Network,DNSCacheEnable,0)"`
    DNSCacheMaxTTL=`/boot/bin/idleBox.exx "iniGetString($strConfigFile,Network,DNSCacheMaxTTL,0)"`
fi

echo "DNSCacheEnable:"$DNSCacheEnable
echo "DNSCacheMaxTTL:"$DNSCacheMaxTTL

if [ -f "/boot/bin/dnsmasq" -a $DNSCacheEnable = "1" ]; then
    while [ 1 ]
    do
        if [ "$DNSCacheMaxTTL" -gt 0 ]; then
            /boot/bin/dnsmasq -r /etc/resolv_dnsmasq.conf -u root -k --max-cache-ttl $DNSCacheMaxTTL
        else
            /boot/bin/dnsmasq -r /etc/resolv_dnsmasq.conf -u root -k
        fi
    done
fi

