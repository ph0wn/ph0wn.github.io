#!/bin/sh
#
#path to export
#
export PATH=$PATH:/phone/bin/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/boot/lib:/phone/lib
export DBUS_FATAL_WARNINGS=0

cd /phone/bin
#
#create dbus folder
#
rm -rf /var/run/dbus/
mkdir -p /var/run/dbus/

#
#start dbus
#
killall dbus-daemon
#dbus-daemon --config-file=/config/bluetooth/dbus-1/system.conf --fork
DBUS_SESSION=`/phone/bin/dbus-daemon --config-file=/config/bluetooth/dbus-1/system.conf --fork --print-address`
#
#start bluetoothd
#
killall bluetoothd
#we need bluez log to dump to console.
bluetoothd -n &

export DBUS_SESSION_BUS_ADDRESS=$DBUS_SESSION

killall obex-client
/phone/bin/obex-client &
#
#load bluetooth driver
#
mknod /dev/pcm_hook c 249 0
insmod pcm_hook.ko


#
#run bluetooth
#
#killall bluetooth_demo
#./bluetooth_demo
