#!/bin/sh
PATH=$PATH:/phone/bin

if [ -x /phone/bin/Screen.exe ]
then
    /phone/bin/Screen.exe -byzero
else
    /phone/bin/Screen.exx -byzero
fi
