#!/bin/sh
#
# Shell script to reset config/data to factory status
#

############################################
echo ""
echo "====================================="
echo "========Enter factory Mode =========="

############################################
# factory common function APIs

#sync single dir except the subdir
sync_single_dir()
{
# $1 srcDir
# $2 dstDir
    if [ ! -e $2 ]; then
        mkdir -p $2
    fi
    if [ ! -e $1 ] || [ ! -e $2 ]; then
        echo src dir $1 or dst dir $2 not exist
        return;
    fi

    for file in `ls $1`; do
        if [ -d $1/$file ]; then
            echo $1/$file is a dir no need sync
        else
            echo copy $1/$file to $2
            cp -a $1/$file $2 2>/dev/null
        fi
    done
}

#sync dir except the subdir contained $3
sync_dir_except()
{
# $1 srcDir
# $2 dstDir
# $3 subdir to ignore
    echo sync_dir_except $1 $2 $3
    if [ ! -e $1 ] || [ ! -e $2 ]; then
        echo src dir $1 or dst dir $2 not exist
        return;
    fi

    for file in `ls $1`; do
        if [ ! -x /boot/bin/cfgserver ] || [ $file != "factory.dbx" ]; then
            if [ "`echo $1/$file | grep $3`" != "$1/$file" ]; then
                echo copy $1/$file to $2
                cp -a $1/$file $2 2>/dev/null
	    else
	            echo no need to copy $1/$file to $2
	    fi
        else
            echo no need to copy $1/$file to $2
        fi
    done
}

msg_any()
{
    echo $1
}
msg_die()
{
    echo $1
    exit 1
}
msg_dbg()
{
    if [ $bVerbose -ne 0 ];then
        echo $1;
    fi
}

killall_app()
{
    pid=`ps |awk '{print $1}'`
    mypid=`ps |grep factory.sh |awk '{print $1}'`

    for j in $pid
    do
        if [ ! -e /proc/$j/status ];then
            continue;
        fi
        pname=`cat /proc/$j/status |grep Name | awk '{print $2}'`
        if [ "$pname" == "init" ] || [ "$pname" == "sh" ] || [ "$pname" == "factory.sh" ] || [ "$pname" == "udevd" ] || [ "$pname" == "PID" ];then
            continue;
        fi
        kill -9 $j
    done
}

fs_mount()
{
    local retry=3
    local result

    while [ $retry -gt 0 ]
    do
        mount -t $1 -o $2 $3 $4 >> /dev/null 2>&1
        sleep 1

        result=`mount | grep $4`
        if [ "$result" != "" ];then
            return 0
        fi

        retry=$(expr $retry - 1)
        msg_dbg "mount -t $1 -o $2 $3 $4,fail,retry it"
    done

    msg_any "mount -t $1 -o $2 $3 $4,fail"
    return 1
}

fs_umount()
{
    local retry=3
    local result

    while [ $retry -gt 0 ]
    do
        umount -f $1 >> /dev/null 2>&1
        sleep 1

        result=`mount | grep $1`
        if [ "$result" == "" ];then
            return 0
        fi

        retry=$(expr $retry - 1)
        msg_dbg "umount -f $1,fail,retry it"
    done

    msg_any "umount -f $1,fail!"
    return 1
}

############################################

# factory params default value
bVerbose=0
bReboot=0
bResetConfig=0
bResetUserData=0
bBackupCustomFactory=0
cfgSystem=/config/system/system.ini

devid=`cat /proc/hwversion | cut -d "." -f1`
if [ -x /boot/bin/cfgserver ];then
eFactoryOption=`/boot/bin/cfgserver get features.factory_reset_option 3` 
bEnableCustomFactory=`/boot/bin/cfgserver get features.custom_factory_config.enable 0` 
bEnableCustomUserdata=`/boot/bin/cfgserver get features.custom_factory_userdata.enable  0`
else
eFactoryOption=`/boot/bin/idleBox.exx "iniGetString($cfgSystem,Factory,eResetOption,3)"`
bEnableCustomFactory=`/boot/bin/idleBox.exx "iniGetString($cfgSystem,Factory,bEnableCustom,0)"`
bEnableCustomUserdata=`/boot/bin/idleBox.exx "iniGetString($cfgSystem,Factory,bEnableCustomUserdata,0)"`
fi

PHONETYPE=`/phone/scripts/GetPhoneType.sh`
PHONEVERSION=`/phone/scripts/GetPhoneType.sh version`

############################################
if [ "$eFactoryOption" == "1" ];then
    msg_any "Reset Config Only"
    bReboot=1
    bResetConfig=1
    bResetUserData=0
elif [ "$eFactoryOption" == "2" ];then
    msg_any "Reset Userdata Only"
    bReboot=1
    bResetConfig=0
    bResetUserData=1
else
    msg_any "cfgfile($cfgSystem) unsupport item(eResetOption=$eFactoryOption),we reset all"
    bReboot=1
    bResetConfig=1
    bResetUserData=1
fi

msg_any "cfgfile($cfgSystem) setting:bReboot=$bReboot,bResetConfig=$bResetConfig,bResetUserData=$bResetUserData"

############################################
while [ -n "$1" ]
do
    case $1 in
        -noreboot)
        bReboot=0;
        shift 1
        ;;

        -all)
        bResetConfig=1;
        bResetUserData=1;
        shift 1;
        ;;

        -resetconfig)
        bResetConfig=1;
        bResetUserData=0;
        shift 1;
        ;;

        -resetuserdata)
        bResetConfig=0;
        bResetUserData=1;
        shift 1;
        ;;

        -v|--verbose)
        bVerbose=1;
        shift 1;
        ;;

        *)
        msg_die "Input option($1) invalid,Only support:-noreboot,-resetconfig,-resetuserdata"
        ;;
    esac
done


msg_any "factory final setting:bReboot=$bReboot,bResetConfig=$bResetConfig,bResetUserData=$bResetUserData"

############################################
msg_dbg ""
msg_dbg "enter critical area"
/boot/bin/userenv -s resetflag -v 1

if [ -x /boot/bin/cfgserver ] && [ $bResetConfig -eq 1 ];then
    /boot/bin/userenv -s NeedCustomFac -v 1
fi
############################################
msg_dbg "Close watch dog"
if [ -x /boot/bin/cfgserver ];then
/boot/bin/cfgserver set watch_dog.enable 0 >> /dev/null 2>&1 
else
/boot/bin/idleBox.exx "regSetString($cfgSystem, WatchDog, bEnable, 0)" >> /dev/null 2>&1
fi
echo 0 > /proc/keypad/watchdog

if [ "$PHONEVERSION" == "80" ] || [ "$PHONEVERSION" == "8" ] || [ "$PHONEVERSION" == "81" ]; then
    /boot/bin/idleBox.exx 'msgBroadcastPostMessage(0x00000083, 0, 0)'
else
    /boot/bin/idleBox.exx 'msgBroadcastPostMessage(0x1000a, 0, 0)'
fi

#��ǰ����������һ������T46��CP860��T48��T29��T69
blockConfigDataSame=0
devBlockConfig=`mount | grep "/config " | awk '{print $1}'`
devBlockData=`mount | grep "/data " | awk '{print $1}'`
if [ $devBlockConfig == $devBlockData ];then
    blockConfigDataSame=1
fi

############################################
msg_dbg "Kill all app"
killall_app
killall_app

msg_dbg "Close watch dog again"
echo 0 > /proc/keypad/watchdog

## Recovery Web resource
if [ -f /phone/www/WEB-INFO/scripts/webrecovery.sh ]; then
   /phone/www/WEB-INFO/scripts/webrecovery.sh
elif [ -f /phone/html/WEB-INFO/scripts/webrecovery.sh ]; then
   /phone/html/WEB-INFO/scripts/webrecovery.sh 
fi

############################################
# README:
# bResetConfig = 1, will recove 'config data', bResetUserData = 1, will recover 'user data'
# /tmp/customfactory.recover: to save custom factory, which is /data/customfactory
# /tmp/config.userdata      : to save custom userdata, whitch is /config/data/contact_group_list.xml,contact_list.xml,call_data.xml
#                             and if bEnableCustomUserdata = 0, these three file belongs to 'config data', 
#                             if bEnableCustomUserdata = 1, these three files belongs to 'user data'
# /tmp/config.recover       : to save 'config data', if bEnableCustomFactory = 0, then means /phone/factory/*; 
#                             if bEnableCustomFactory = 1, then means /data/customfactory/*;
#/tmp/config.data           : if device haven't bock 12 for data partition,backup the /data to /tmp/config.data when didn't need resetuserdata
#
############################################
# reset custom userdata
if [ $bResetUserData -eq 1 ];then
    if [ "$bEnableCustomUserdata" == "1" ];then
    	msg_any "Reset custom userdata"
        cp -p /phone/factory/data/contact_group_list.xml /config/data
        cp -p /phone/factory/data/contact_list.xml /config/data
        cp -p /phone/factory/data/call_data.xml /config/data
        if [ $PHONETYPE == "DECT" ];then
            cp -p /phone/factory/data/contact_handset*.xml /config/data/
        fi
    fi
elif [ $blockConfigDataSame -eq 1 ]; then
    #because no config partition
    msg_any "backup data to config.data"
    mkdir /tmp/config.data
    cp -a /data/* /tmp/config.data/     
fi

# Backup custom config
if [ "$bEnableCustomFactory" == "1" -a -e /data/customfactory ]; then
    bBackupCustomFactory=1
    msg_any "Backup custom factory"
    mkdir -p /tmp/customfactory.recover
    cp -a /data/customfactory/* /tmp/customfactory.recover
    cp -a /config/data/htpasswd /tmp
fi

############################################
if [ $bResetConfig -eq 1 ];then
    msg_any ""
    msg_any "Reset config start"

    # Create backup dir
    msg_dbg "mkdir /tmp/config.recover"
    rm -rf /tmp/config.recover >> /dev/null 2>&1
    mkdir -p /tmp/config.recover


    cfgUser=/config/user/user.ini
    if [ -x /boot/bin/cfgserver ];then
        bIsReserveCerts=`/boot/bin/cfgserver get phone_setting.reserve_certs_enable 0`
        bEnableProviderLock=`/boot/bin/cfgserver get phone_setting.provider_lock.enable 0`
    else
        bIsReserveCerts=`/boot/bin/idleBox.exx "iniGetString($cfgUser,PhoneSetting,IsReserveCerts,0)"`
        bEnableProviderLock=`/boot/bin/idleBox.exx "iniGetString($cfgUser,PhoneSetting,bEnableProviderLock,0)"`
    fi
    echo ReserveCerts=$bIsReserveCerts
    if [ "$bIsReserveCerts" == "1" ];then
        if [ -e /config/certs ] ; then
            rm -rf /tmp/certs >> /dev/null 2>&1
            cp -a /config/certs/ /tmp
        fi
        if [ -e /config/Setting ] ; then
            rm -rf /tmp/Setting >> /dev/null 2>&1
            cp -a /config/Setting /tmp
        fi
    else
        # Backup Config(phonedev,Setting)
        msg_dbg "Backup Config(phonedev,Setting)"
        if [ -e /config/certs/phonedev ];then
            msg_dbg "cp -a /config/certs/phonedev /tmp"
            rm -rf /tmp/phonedev >> /dev/null 2>&1
            cp -a /config/certs/phonedev /tmp

            msg_dbg "cp -a /config/Setting /tmp"
            rm -rf /tmp/Setting >> /dev/null 2>&1
            cp -a /config/Setting /tmp
        fi
        # Backup Lync License
        if [ -e /config/certs/uc ];then
            msg_any "cp -a /config/certs/uc /tmp"
            rm -rf /tmp/uc >> /dev/null 2>&1
            cp -a /config/certs/uc /tmp
        fi
    fi
    
    # Backup factory sn
    if [ -e /config/vpPhone ] ; then
        rm -rf /tmp/vpPhone >> /dev/null 2>&1
        cp -a /config/vpPhone /tmp    
    fi
    
    # Backup custom userdata
    if [ "$bEnableCustomUserdata" == "1" ];then
        mkdir -p /tmp/config.userdata
        cp -p /config/data/contact_group_list.xml /tmp/config.userdata
        cp -p /config/data/contact_list.xml /tmp/config.userdata
        cp -p /config/data/call_data.xml /tmp/config.userdata
        if [ $PHONETYPE == "DECT" ];then
            cp -p /config/data/contact_handset*.xml /tmp/config.userdata
        fi
    fi
    
    # Backup provider lock config
    if [ "$bEnableProviderLock" == "1" -a -f /config/providerLock.cfg.bak ];then
        cp -p /config/providerLock.cfg.bak  /tmp/providerLock.cfg.bak
    fi

    # umount config partition
    fs_umount /etc
    fs_umount /config
    if [ $blockConfigDataSame -eq 1 ]; then
        fs_umount /data
    fi
    # Erase config partition
    flash_eraseall /dev/mtd11
    sleep 1
    # mount config partition

    if [ $blockConfigDataSame -eq 1 ]; then
        fs_mount jffs2 sync,rw /dev/mtdblock11 /config
    else
        fs_mount yaffs2 rw /dev/mtdblock11 /config
    fi
    if [ $? -ne 0 ];then
        msg_die "mount /dev/mtdblock11 -> /config failed"
    fi
    if [ $blockConfigDataSame -eq 1 ]; then
        mkdir /config/upload
        mount --bind /config/upload /data
        if [ $bResetUserData -eq 0 ];then
            msg_any "restore data"
            cp -a /tmp/config.data/* /data/
        fi
    fi



    # recover /config/certs/phonedev
    #ReserveCerts only sync /certs/* (not include the subdir but) /certs/phonedev /certs/server
    if [ "$bIsReserveCerts" == "1" ];then
        if [ -d /tmp/certs ] ; then
            echo old certs recove to config begin
            sync_single_dir /tmp/certs  /config/certs
            sync_single_dir /tmp/certs/phonedev  /config/certs/phonedev
            sync_single_dir /tmp/certs/server  /config/certs/server
            sync_single_dir /tmp/certs/uc  /config/certs/uc
            sync_single_dir /tmp/Setting  /config/Setting
            rm -rf /tmp/certs
            echo old certs recove to config end
        fi
    else
        if [ -e /tmp/phonedev ] ; then
            if [ ! -e /config/certs ] ; then
                mkdir -p /config/certs
            fi
            cp -a /tmp/phonedev /config/certs
            cp -a /tmp/Setting /config
            rm -fr /tmp/phonedev
            rm -fr /tmp/Setting
        fi
        if [ -e /tmp/uc ];then
            msg_any "Recover Lync License"
            if [ ! -e /config/certs ] ; then
                mkdir -p /config/certs
            fi
            cp -a  /tmp/uc /config/certs
            rm -fr /tmp/uc
        fi
    fi


    # Recover factory config
    if [ "$bEnableCustomFactory" == "1" -a -e /tmp/customfactory.recover ] && [ "$bBackupCustomFactory" == "1" ];then
        msg_any "copy /tmp/customfactory.recover/* -> /tmp/config.recover"
        cp -a /tmp/customfactory.recover/* /tmp/config.recover
        
        msg_any "Recover custom factory data"
        mkdir -p /config/data
        cp -a /tmp/customfactory.recover/data/* /config/data
        cp -a /tmp/htpasswd /config/data

        # recover cert file
        mkdir -p /config/certs
        cp -a /tmp/customfactory.recover/certs/* /config/certs

        # recover vpn file
        mkdir -p /config/openvpn
        cp -a /tmp/customfactory.recover/openvpn/* /config/openvpn

        # recover ime file
        mkdir -p /config/ime
        cp -a /tmp/customfactory.recover/ime/* /config/ime
    else
        msg_any "Recover factory data"
        cp -a /phone/factory/* /tmp/config.recover

        # recover data file
        mkdir -p /config/data
        cp -a /phone/factory/data/* /config/data

        # recover cert file
        mkdir -p /config/certs
        cp -a /phone/factory/certs/* /config/certs

        # recover vpn file
        mkdir -p /config/openvpn
        cp -a /phone/factory/openvpn/* /config/openvpn

        # recover ime file
        mkdir -p /config/ime
        cp -a /phone/factory/ime/* /config/ime
    fi
    
    # copy which need update
    msg_any "Recover passwd/group"
    mkdir -p /config/etc
    cp -a /etc/shadow  /config/etc
    cp -a /etc/passwd  /config/etc
    cp -a /etc/group   /config/etc

    mount --bind /config/etc /etc

    if [ ! -x /boot/bin/cfgserver ];then 
        #reset config file
        msg_any "Reset config file"
        /boot/bin/idleBox.exx 'configResetFacory(/config, /tmp/config.recover)'
    fi

    #cp -a /tmp/config.recover/* /config
    sync_dir_except /tmp/config.recover /config /certs

    if [ $blockConfigDataSame -eq 1 ];then
        if [ "$bBackupCustomFactory" == "1" ];then
            mkdir /data/customfactory
            cp -a /tmp/config.recover/* /data/customfactory/
        fi
        rm -rf /tmp/config.recover
        fs_umount /data
    fi
    
    # Recover factory sn
    if [ -e /tmp/vpPhone ] ; then
        msg_any "Recover factory sn"
        cp -a /tmp/vpPhone /config
        rm -fr /tmp/vpPhone
    fi
    
    # Recover custom userdata
    if [ "$bEnableCustomUserdata" == "1" ];then
    	msg_any "Recover custom userdata"
        if [ -e /tmp/config.userdata ];then
            cp -a /tmp/config.userdata/* /config/data
        fi
	rm -rf /tmp/config.userdata
    fi
    
    # Recover provider lock config
    if [ "$bEnableProviderLock" == "1" -a -f /tmp/providerLock.cfg.bak ];then
    	msg_any "Recover provider lock config"
        cp -p /tmp/providerLock.cfg.bak /config/providerLock.cfg
        cp -p /tmp/providerLock.cfg.bak /config/providerLock.cfg.bak
        rm -rf /tmp/providerLock.cfg.bak
    fi
    
    rm -rf /tmp/config.recover

	# sync custom config
    #if [ ! -x /boot/bin/cfgserver ];then  
        /boot/bin/configTranslate.exx customfactory
    #fi

    ## umount config partition
    fs_umount /etc
    fs_umount /config

    msg_any "Reset config done"
fi

############################################
if [ $bResetUserData -eq 1 ];then
    if [ $blockConfigDataSame -eq 0 ];then
        msg_any ""
        msg_any "Reset user data start"

        # umount data partition
        fs_umount /data
        # erase data partition
        flash_eraseall /dev/mtd12
        sleep 1
        # remount data partition
        fs_mount yaffs2 rw /dev/mtdblock12 /data
        if [ $? -ne 0 ];then
            msg_die "mount /dev/mtdblock12 -> /data failed"
        fi

        # recover data
        if [ "$bBackupCustomFactory" == "1" ];then
            mkdir -p /data/customfactory
            msg_any "copy /tmp/customfactory.recover/* -> /data/customfactory/"
            cp -a /tmp/customfactory.recover/* /data/customfactory/
        
            # recover customfactory userdata
            if [ -e /data/customfactory/userdata ];then
                mkdir -p /data/userdata
                msg_any "copy /data/customfactory/userdata/* -> /data/userdata"            
                cp -a /data/customfactory/userdata/* /data/userdata
            fi
        fi

        rm -rf /tmp/customfactory.recover

        # umount data partition
        fs_umount /data
    else
        rm -rf /data/*
    fi
    msg_any "Reset user data done"
fi


############################################
/boot/bin/userenv -s resetflag -v 0
msg_dbg ""
msg_dbg "exit critical area"

############################################
if [ $bReboot -eq 1 ];then
    msg_any ""
    msg_any "Now reset system!"
    sync;sleep 1
    sync;sleep 1

    echo 201 > /proc/keypad/watchdog
    echo 201 > /proc/keypad/watchdog

    msg_any "Wait system reset"
    sleep 2

    msg_any "watchdog reset failed,try reboot!"
    reboot
fi

############################################
echo "=========Exit factory Mode =========="
echo "====================================="

############################################
