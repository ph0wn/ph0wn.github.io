#!/bin/sh

killall -9 lighttpd fcgiServer.exx 2> /dev/null

##���ø�Ŀ¼
if [ -e "/phone/html" ];then
	ROOT_DIR="/phone/html/"
	CUSTROM_ROOT="/config/"
fi

if [ -e "/yealink/html" ];then
	ROOT_DIR="/yealink/html/"
	CUSTROM_ROOT="/yealink/config/"
fi

if [ -e "/phone/www/" ];then
	ROOT_DIR="/phone/www/"
	CUSTROM_ROOT="/config/"
fi

DIR_SCRIPTS=${ROOT_DIR}WEB-INFO/scripts/

# Web Custom picture and color
if [ -f ${DIR_SCRIPTS}/themes.sh ]; then
	${DIR_SCRIPTS}themes.sh $1
fi

# Web Access Timer 
# idleBox.exx��Ҫ��GUI���£������ε�
# if [ -f ${DIR_SCRIPTS}webtimer.sh ]; then
# 	kill -9 `ps | grep webtimer.sh | grep -v grep | cut -c 1-6`
# 	${DIR_SCRIPTS}webtimer.sh &
# fi
echo "***********end done**************"
