#!/bin/sh
#
# Recovery Web resource
#

fs_umount()
{
    local retry=3
    local result

    while [ $retry -gt 0 ]
    do
        umount -f $1 >> /dev/null 2>&1
        sleep 1
        
        result=`mount | grep $1`
        if [ "$result" == "" ];then
            return 0
        fi

        retry=$(expr $retry - 1)
        msg_dbg "umount -f $1,fail,retry it" 
    done

    msg_any "umount -f $1,fail!"
    return 1
}

if [ -e "/phone/html" ];then
	ROOT_DIR="/phone/html/"
fi

if [ -e "/yealink/html" ];then
	ROOT_DIR="/yealink/html/"
fi

if [ -e "/phone/www/" ];then
	ROOT_DIR="/phone/www/"
fi

echo "Start to recovery web resource"

fs_umount $ROOT_DIR/htdocs/custom

echo "end done : recovery web resource"
