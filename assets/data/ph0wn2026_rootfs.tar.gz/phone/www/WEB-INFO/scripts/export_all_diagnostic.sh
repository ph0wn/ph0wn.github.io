#!/bin/sh
#
# Shell script to start yealink applications on /phone
#
# Copyright 2010-2015 XIAMEN YEALINK NETWORK TECHNOLOGY CO.,LTD
#
#       Revision History:
#       Version         Author          Date                            History
#       1.0.0.1         wangxp          2016-12-05                			First Revision
#***********************************************************************

echo Runing /phone/script/export_all_diagnostic.sh

sysConfigFile=/config/system/system.ini

if [ -x /boot/bin/cfgserver ];then
    strLocalPath=`/boot/bin/cfgserver get syslog.local_path /tmp/log/`
else
    strLocalPath=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,Syslog,strLocalPath,/tmp/log/)"`
fi
strLogExport="$strLocalPath""*"

if [ -x /boot/bin/cfgserver ];then
    strClipFilePrefix=`/boot/bin/cfgserver get priv.gui.packetcapture.strclipfileprefix /tmp/pcap/data`
else
    strClipFilePrefix=`/boot/bin/idleBox.exx "regGetString($sysConfigFile,PacketCapture,strClipFilePrefix,/tmp/pcap/data)"`
fi
strPcapExport="$strClipFilePrefix""*"

rm -rf $strPcapExport

ALL_PRINT_FILE="$strLocalPath""allprint.log"
rm -rf $ALL_PRINT_FILE

cat /proc/uptime >> $ALL_PRINT_FILE
ifconfig >> $ALL_PRINT_FILE
ps >> $ALL_PRINT_FILE
top -b -n 1 -d 1 >> $ALL_PRINT_FILE
free >> $ALL_PRINT_FILE
cat /proc/meminfo >> $ALL_PRINT_FILE
cat /proc/buddyinfo >> $ALL_PRINT_FILE
df >> $ALL_PRINT_FILE
netstat -a >> $ALL_PRINT_FILE

tar -cvf /tmp/allconfig.tar $strLogExport /tmp/*.pcap /tmp/config.bin

rm -rf $ALL_PRINT_FILE /tmp/*.pcap /tmp/config.bin

# nothing past this point #
